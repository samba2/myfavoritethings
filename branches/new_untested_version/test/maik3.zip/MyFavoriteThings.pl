#!/usr/bin/perl -w

use strict;
use Carp;
use CGI;
use lib "./lib"; 
use MyFav::DB;
use MyFav::View;
use MyFav::Setup;
use MyFav::CheckInput;

# TODO initial setup

my $setup = MyFav::Setup->new();

my $dataBaseDir = $setup->getDataBaseDir();
my $templateDir = $setup->getTemplateDir();
my $scriptUrl = $setup->getScriptUrl();

my $query = new CGI;
my $releaseCode = $query->param("release");
my $wizardState = $query->param("wizard");

my $configDb = MyFav::DB->new("dataBaseName" => "config", "dataBaseDir" => $dataBaseDir);
my $tempDb = MyFav::DB->new("dataBaseName" => "temp", "dataBaseDir" => $dataBaseDir);
my $template = MyFav::View->new("templateDir" => $templateDir);


if (! $configDb->dataBaseExists()) {
	$configDb->createConfigDataBase();
	$configDb->fillWithConfigDefaults();
}

if (! $tempDb->dataBaseExists()) {
	$tempDb->createTempDataBase();
}

print $query->header;


$template->setParam("VERSIONID", $configDb->getVersionId());
$template->setParam("SCRIPTURL", $scriptUrl);
    
#if ( ! $releaseCode) {
	
#	$template->printHtml("noReleaseCodeSupplied.tmpl");
#}




my %cgiParams = $query->Vars;
	
my $inputChecker = MyFav::CheckInput->new(%cgiParams);
 	
if ($wizardState eq "stard") {
	$template->printHtml("wizardProjectDetails.tmpl");
}
elsif ($wizardState eq "releaseDetails") {

	my $error = $inputChecker->checkWizardReleaseDetails();
	
	# if error exists, fill template object with error message and submitted data and redisplay
	if ($error) {
		$template->setParam("ERRORMESSAGE", $error);
		$template->setParam("RELEASENAME", $cgiParams{"releaseName"});
		$template->setParam("RELEASEID", $cgiParams{"releaseId"});
		$template->printHtml("wizardProjectDetails.tmpl");
	}
	else {
		# remember release data
		$tempDb->cleanTemporaryValues();
		$tempDb->insertValue("releaseName",$cgiParams{"releaseName"});
		$tempDb->insertValue("releaseId",$cgiParams{"releaseId"});
				
		$template->printHtml("wizardNumberOfCodes.tmpl");	
	}
}
elsif ($wizardState eq "numberOfCodes") {
	my $error = $inputChecker->checkWizardNumberOfCodes();
	
	if ($error) {
		$template->setParam("ERRORMESSAGE",$error);
		$template->setParam("CODECOUNT", $cgiParams{"codeCount"});
		$template->printHtml("wizardNumberOfCodes.tmpl");	
	}
	else {
		$tempDb->insertValue("codeCount",$cgiParams{"codeCount"});
		$template->printHtml("wizardUploadZipFile.tmpl");
	}
}
elsif ($wizardState eq "uploadZip") {
	print $wizardState;
	$template->printHtml("wizardReleaseCreated.tmpl");
	print $wizardState;

}			
   
#	$template->printHtml("noReleaseCodeSupplied.tmpl");


#	my $codeDb = MyFav::DB->new("dataBaseName" => "$releaseCode", "dataBaseDir" => $dataBaseDir);



#	if (! $codeDb->dataBaseExists()) {
		# TODO test for ! "starts with non-alphabetic character"
		# info: legt case sensitive dateinamen an
#		$codeDb->createReleaseDataBase();
		# TODO remove default code number
#		my $codeCount = 10;
#		$codeDb->fillReleaseDataBaseWithNewCodes($codeCount);
#	}
#	$template->printHtml("enterCode.tmpl");



